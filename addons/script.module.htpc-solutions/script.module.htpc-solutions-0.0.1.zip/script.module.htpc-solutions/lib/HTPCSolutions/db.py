
from debug import Debug
from tinydb import TinyDB, where

import os
import xbmc, xbmcaddon, xbmcgui, xbmcplugin

####################################################################################################

class DB(Debug, TinyDB):

	def __init__(self):

		self.filename = xbmc.translatePath("special://userdata/addon_data/%s/db.json" % ( xbmcaddon.Addon().getAddonInfo('id') ) )

		if not os.path.isdir(os.path.dirname(self.filename)):
			self.debug("Directory does not exist. Creating - %s" % os.path.dirname(self.filename))
			os.makedirs(os.path.dirname(self.filename))

		super(DB, self).__init__(self.filename)