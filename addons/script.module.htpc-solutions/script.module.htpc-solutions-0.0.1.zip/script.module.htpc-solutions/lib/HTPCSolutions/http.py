from cookies import Jar
from debug import Debug
from urllib import quote_plus, unquote_plus

import json
import os
import urllib, urllib2
import xbmc

####################################################################################################

class HTTP(Debug):

	def __init__(self):

		super(HTTP, self).__init__()

		self.cookies = Jar()

	def download(self, url, filename, data=None):
		
		response = self.url(url, data)

		if response == None:
			return False

		if not os.path.isdir(os.path.dirname(filename)):
			self.debug("Directory does not exist. Creating - %s" % os.path.dirname(config_file))
			os.makedirs(os.path.dirname(filename))
			
		fp = open(filename, 'w')
		fp.write(response)
		fp.close()

		return True

	def json(self, url, data=None):
		
		data = self.url(url, data)

		# Check to see if we've received anything.
		if data == "":
			self.debug("JSON is invalid")
			return json.loads({})
		
		return json.loads(data)

	def url(self, url, data=None):
				
		# create opener
		opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(self.cookies._jar))
		headers = [('User-Agent', 'HTPC Solutions/1.0')]
		
		# do we have to post data
		if data:
			data = urllib.urlencode(data)
			headers += [('Content-type', 'application/x-www-form-urlencoded')]
		
		# add headers
		opener.addheaders = headers

		# perform request
		try:
			
			# perform request
			usock = opener.open(url, data)
			response = usock.read()
			usock.close()

			self.cookies.save()

			return response
		
		except urllib2.HTTPError, error:
		 	self.debug('%s - %s - %s' % (error.code, error.msg, error.geturl()), xbmc.LOGERROR)
		
		except Exception, error:
			self.debug('%s - %s' % (Exception.__module__, error), xbmc.LOGERROR)

		return None

####################################################################################################