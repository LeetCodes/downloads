
from debug import Debug

import cookielib
import os
import xbmc, xbmcaddon, xbmcgui, xbmcplugin

####################################################################################################

addon = xbmcaddon.Addon()

####################################################################################################

class Cookie(Debug):

	def __init__(self, **kwargs):

		self.debug(kwargs)

		self.name = kwargs.pop('name', "")
		self.value = kwargs.pop('value', "")
		self.path = kwargs.pop('path', "/")
		self.domain = kwargs.pop('domain', "")

		self.version = kwargs.pop('version', 0)
		self.port = kwargs.pop('port', None)
		self.secure = kwargs.pop('secure', False)
		self.expires = kwargs.pop('expires', None)
		self.discard = kwargs.pop('discard', False)
		self.comment = kwargs.pop('comment', None)
		self.comment_url = kwargs.pop('comment_url', None)
		self.rest = kwargs.pop('rest', {})
		self.rfc2109 = kwargs.pop('rfc2109', False)

		self.debug("name: {0}, value: {1}, path: {2}, domain: {3}".format(self.name, self.value, self.path, self.domain))

	@property
	def lwp(self):
		
		self.debug("Retrieiving LWP Compliant Cookie Object")
		
		return cookielib.Cookie(
			self.version,
			self.name,
			self.value,
			self.port,
			self.port_specified,
			self.domain,
			self.domain_specified,
			self.domain_initial_dot,
			self.path,
			self.path_specified,
			self.secure,
			self.expires,
			self.discard,
			self.comment,
			self.comment_url,
			self.rest,
			self.rfc2109
		)

	@property
	def domain_specified(self):
		return self.domain != None or self.domain != ""

	@property
	def domain_initial_dot(self):
		return self.port != None	

	@property
	def path_specified(self):
		return self.path != None or self.path != ""

	@property
	def port_specified(self):
		return self.port != None		

####################################################################################################

class Jar(Debug):

	filename = xbmc.translatePath("special://userdata/addon_data/%s/cookies.lwp" % ( addon.getAddonInfo('id') ) )

	def __init__(self):

		self._discard_ignore = True
		self._jar = cookielib.LWPCookieJar()

		self.load()

	def clear(self, name=None, domain=None, path=None):
		
		self._jar.clear(domain, path, name)

	def get(self, name=None, domain=None, path=None):
		
		for cookie in self._jar:
			if (cookie.name == name):
				return cookie
		return None

	def load(self):

		self.debug(Jar.filename)
		if os.path.isfile(Jar.filename):
			self.debug("Loading Cookie File")
			self._jar.load(Jar.filename)
		self.debug(self._jar)
			
	def save(self):

		if not os.path.isdir(os.path.dirname(Jar.filename)):
			self.debug("Directory does not exist. Creating - %s" % os.path.dirname(Jar.filename))
			os.makedirs(os.path.dirname(Jar.filename))

		self._jar.save(filename=Jar.filename, ignore_discard=self._discard_ignore)

	def set(self, **kwargs):
	
		c = Cookie(**kwargs)
		self._jar.set_cookie(c.lwp)
		self.save()

####################################################################################################