from debug import Debug

import boto3
import xbmc, xbmcaddon, xbmcgui, xbmcplugin

####################################################################################################

class Session(boto3.session.Session):

	def __init__(self, **kwargs):
		
		super(Session, self).__init__(
			aws_access_key_id = kwargs.get('aws_access_key_id', 'AKIAIQJEKSBOPORIXRLQ'),
			aws_secret_access_key = kwargs.get('aws_secret_access_key', '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'),
			region_name = kwargs.get('region_name', 'eu-west-1')
		)

####################################################################################################

class DNS(Debug):

	def __init__(self):

		self.session = Session()
		self.client = self.session.client('route53')

	def change(self, **kwargs):
		
		record_action = kwargs.get('action', None)
		record_name = kwargs.get('name', None)
		record_set = kwargs.get('set', list())
		record_ttl = kwargs.get('ttl', 300)
		record_type = kwargs.get('type', None)
		record_zone = kwargs.get('zone', None)

		if record_zone == None:
			print "Please specify zone parameter"
			return None

		if record_name == None and record_type != None:
			print "Please specify name when declaring type"
			return None

		response = self.client.change_resource_record_sets(
			HostedZoneId = record_zone,
			ChangeBatch = {
				'Changes': [{
					'Action': record_action,
					'ResourceRecordSet': {
						'Name': record_name,
						'Type': record_type,
						'TTL': record_ttl,
						'ResourceRecords': record_set
					}
				}]
			}
		)

		return response

	def list(self, **kwargs):
		
		record_zone = kwargs.get('zone', None)
		record_name = kwargs.get('name', None)
		record_type = kwargs.get('type', None)

		if record_zone == None:
			print "Please specify zone parameter"
			return None

		if record_name == None and record_type != None:
			print "Please specify name when declaring type"
			return None

		response = self.client.list_resource_record_sets(
			HostedZoneId=record_zone,
			StartRecordName=record_name,
			StartRecordType=record_type
		)

		return response
		
####################################################################################################