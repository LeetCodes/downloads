from ConfigParser import ConfigParser

import collections
import HTPCSolutions
import json
import operator
import subprocess
import sys
import xbmc, xbmcaddon

####################################################################################################

addon = xbmcaddon.Addon()
config = ConfigParser()

db = HTPCSolutions.DB()
parameters = HTPCSolutions.Parameters()
ui = HTPCSolutions.UI()
where = HTPCSolutions.where

####################################################################################################

class Main(HTPCSolutions.Debug):

	def __init__(self):

		self._commands = db.table('commands')

		if parameters.count() < 1:
			self.debug("action is default")
			self.list()
			
		else:
			ui.end(False)


	def list(self):
		commands = self._commands.all()
		for cmd in commands:
			ui.add(cmd["name"], "command", "run", image=None, isFolder=False, params = dict(cmd) )
		ui.end()

####################################################################################################

if __name__ == "__main__":
	Main()
