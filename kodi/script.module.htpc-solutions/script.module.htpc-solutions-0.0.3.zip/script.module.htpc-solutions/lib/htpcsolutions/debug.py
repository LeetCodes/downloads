
import inspect
import xbmc, xbmcaddon, xbmcgui, xbmcplugin

####################################################################################################

addon = xbmcaddon.Addon()

####################################################################################################

def error(message):
	log(message, level = xbmc.LOGERROR)

def fatal(message):
	log(message, level = xbmc.LOGFATAL)

def log(message, **kwargs):

	level = kwargs.get("level", xbmc.LOGNOTICE)

	if addon.getSetting('debug.enabled') == "true":
		stack = inspect.stack()
		xbmc.log("[%s] %s - %s" % ( addon.getAddonInfo('id'), stack[2][3], message) , level)

def notice(message):
	log(message, level = xbmc.LOGNOTICE)

def severe(message):
	log(message, level = xbmc.LOGSEVERE)

def notify(message, **kwargs):

	image = kwargs.get("image", None)
	time = kwargs.get("time", 3000)

	xbmc.executebuiltin( "Notification(%s, %s, %s, %s)" % ( addon.getAddonInfo('name'), message, time, image ) )
