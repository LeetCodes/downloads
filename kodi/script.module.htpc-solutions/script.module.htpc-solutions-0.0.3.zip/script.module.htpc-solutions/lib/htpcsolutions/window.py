import htpcsolutions.debug as debug
import xbmcaddon, xbmcgui

####################################################################################################

addon = xbmcaddon.Addon()

####################################################################################################

class Window(xbmcgui.WindowXMLDialog):

	def clearProperty(self, name, value, **kwargs):
		xbmcgui.Window(self.id).clearProperty(name)

	def setProperty(self, name, value, **kwargs):
		xbmcgui.Window(self.id).setProperty(name, value)

	def onAction(self):
		pass

	def onClick(self):
		pass

	def onFocus(self):
		pass

	def onInit(self):
		self.id = xbmcgui.getCurrentWindowDialogId()





