from cookies import Jar
from urllib import quote_plus, unquote_plus

import htpcsolutions.debug as debug
import inspect
import json
import os
import urllib, urllib2
import xbmc

####################################################################################################

def download(url, filename, data=None):
	
	request = HTTPRequest(
		url = url,
		data = data
	)

	response = request.open()

	if response.data == None:
		return False

	if not os.path.isdir(os.path.dirname(filename)):
		debug.notice("Directory does not exist. Creating - %s" % os.path.dirname(config_file))
		os.makedirs(os.path.dirname(filename))
		
	fp = open(filename, 'w')
	fp.write(response.data)
	fp.close()

	return True

def get(**kwargs):
	return HTTPRequest().open(**kwargs)

def json(url, data=None):

	request = HTTPRequest(
		url = url,
		data = data
	)

	response = request.open()
	json = None

	try:
		
		json.loads(data)
	
	except Exception, err:
		
		if response.data == None:
			debug.error("No Response Data")
		else:
			debug.error("Invlaid Response Data : %s" % response.data)

	return json
		
####################################################################################################

class HTTPRequest():

	def __init__(self, **kwargs):

		self.cookies = kwargs.get('cookies', Jar())
		self.data = kwargs.get('data', None)
		self.headers = kwargs.get('headers', [('User-Agent', 'HTPC Solutions/1.0')])
		self.url = kwargs.get('url', None)

	def open(self, **kwargs):

		cookies = kwargs.get('cookies', self.cookies)
		data = kwargs.get('data', self.data)
		headers = kwargs.get('headers', self.headers)
		url = kwargs.get('url', self.url)
		
		opener = urllib2.build_opener(
			urllib2.HTTPCookieProcessor(cookies)
		)
		
		# do we have to post data
		if not data == None:
			headers += [('Content-type', 'application/x-www-form-urlencoded')]

		# add headers
		opener.addheaders = headers

		response = None
		postdata = None

		if not data == None:
			postdata = urllib.urlencode(data)
		
		# Attemp to perform request
		
		try:

			usock = opener.open(url, postdata)
			response = HTTPResponse(
				code = usock.code,
				cookies = cookies,
				data = usock.read(),
				headers = str(usock.headers),
				message = usock.msg,
				url = usock.url
			)
			usock.close()

		except urllib2.HTTPError, err:
			
			response = HTTPResponse(
				code = err.code,
				data = err.read(),
				headers = str(err.headers),
				message = err.msg,
				url = err.url
			)

		except Exception, err:

			response = HTTPResponse(
				message = err,
				url = url
			)

		return response

####################################################################################################

class HTTPResponse():

	def __init__(self, **kwargs):

		self.code = kwargs.get('code', None)
		self.cookies = kwargs.get('cookies', Jar())
		self.data = kwargs.get('data', None)
		self.headers = kwargs.get('headers', None)
		self.message = kwargs.get('message', None)
		self.url = kwargs.get('url', None)

	def __str__(self):

		if self.code == None:
			return self.data
		else:
			return "%s: %s" % (self.code, self.message)

####################################################################################################
