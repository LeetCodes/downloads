from cookielib import Cookie, LWPCookieJar

import cookielib
import htpcsolutions.debug as debug
import os
import xbmc, xbmcaddon

####################################################################################################

addon = xbmcaddon.Addon()

####################################################################################################

class Cookie():

	def __init__(self, **kwargs):

		self.name = kwargs.pop('name', "")
		self.value = kwargs.pop('value', "")
		self.path = kwargs.pop('path', "/")
		self.domain = kwargs.pop('domain', "")

		self.version = kwargs.pop('version', 0)
		self.port = kwargs.pop('port', None)
		self.secure = kwargs.pop('secure', False)
		self.expires = kwargs.pop('expires', None)
		self.discard = kwargs.pop('discard', False)
		self.comment = kwargs.pop('comment', None)
		self.comment_url = kwargs.pop('comment_url', None)
		self.rest = kwargs.pop('rest', {})
		self.rfc2109 = kwargs.pop('rfc2109', False)

	@property
	def lwp(self):
				
		return cookielib.Cookie(
			self.version,
			self.name,
			self.value,
			self.port,
			self.port_specified,
			self.domain,
			self.domain_specified,
			self.domain_initial_dot,
			self.path,
			self.path_specified,
			self.secure,
			self.expires,
			self.discard,
			self.comment,
			self.comment_url,
			self.rest,
			self.rfc2109
		)

	@property
	def domain_specified(self):
		return self.domain != None or self.domain != ""

	@property
	def domain_initial_dot(self):
		return self.port != None	

	@property
	def path_specified(self):
		return self.path != None or self.path != ""

	@property
	def port_specified(self):
		return self.port != None		

####################################################################################################

class Jar(LWPCookieJar):

	def __init__(self, **kwargs):

		LWPCookieJar.__init__(self)
		self.filename = kwargs.get('filename', xbmc.translatePath("special://userdata/addon_data/%s/cookies.lwp" % ( addon.getAddonInfo('id') ) ) )
		self.load(**kwargs)

	def get(self, **kwargs):

		name = kwargs.get('name', None)
		domain = kwargs.get('domain', None)
		path = kwargs.get('path_specified', None)

		for cookie in self:
			if (cookie.name == name):
				return cookie
		
		return None

	def load(self, **kwargs):

		filename = kwargs.get('filename', self.filename )
		ignore_discard =  kwargs.get('ignore_discard', True)
		ignore_expires =  kwargs.get('ignore_expires', False)

		if os.path.isfile(filename):
			LWPCookieJar.load(self, filename)
			
	def save(self, **kwargs):

		filename = kwargs.get('filename', self.filename )
		ignore_discard =  kwargs.get('ignore_discard', True)

		if not os.path.isdir(os.path.dirname(filename)):
			debug.notice("Directory does not exist. Creating - %s" % os.path.dirname(filename))
			os.makedirs(os.path.dirname(filename))

		LWPCookieJar.save(self, filename = filename, ignore_discard = ignore_discard)

	def set(self, **kwargs):
		self.set_cookie(
			Cookie(**kwargs).lwp
		)
		self.save()

####################################################################################################

def load(**kwargs):
	return  Jar(**kwargs)
