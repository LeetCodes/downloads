import htpcsolutions.debug as debug
import xbmcaddon

####################################################################################################

addon = xbmcaddon.Addon()

####################################################################################################

def clear():
	pass

def get(name = None):
	return addon.getSetting(name)

def open():
	addon.openSettings()

def set(name = None, value = None):
	addon.setSetting(name, value)

####################################################################################################