import htpcsolutions.debug as debug
import htpcsolutions.parameters as parameters
import sys
import xbmc, xbmcaddon, xbmcgui, xbmcplugin

####################################################################################################

addon = xbmcaddon.Addon()

####################################################################################################

def add(title, mode, action, params = {}, image=None, isFolder=True):

	xbmcplugin.setContent( int( sys.argv[1] ), 'movies' )
	
	# create xbmc list item
	item = xbmcgui.ListItem(label=title, iconImage=image, thumbnailImage=image)
	
	params["mode"] = mode
	params["action"] = action
	
	uri = "{0}{1}".format(sys.argv[0], parameters.compose(params) )
	
	xbmcplugin.addDirectoryItem( handle = int(sys.argv[1]), url=uri, listitem=item, isFolder=isFolder )

def dialog(line1 = None, line2 = None, line3 = None):
	xbmcgui.Dialog().ok(addon.getAddonInfo('name'), line1, line2, line3)

def end(sort_method=xbmcplugin.SORT_METHOD_LABEL, update_listing=False):
	
	# Sort methods are required in library mode.
	xbmcplugin.addSortMethod(int(sys.argv[1]), sort_method)
	
	# let xbmc know the script is done adding items to the list.
	xbmcplugin.endOfDirectory(handle = int(sys.argv[1]), updateListing=update_listing)

def notification(message, image=None, time=3000, sound = True):
	if image == None:
		pass
	
	xbmcgui.Dialog().notification( type(self).__name__, message, image, time, sound )

