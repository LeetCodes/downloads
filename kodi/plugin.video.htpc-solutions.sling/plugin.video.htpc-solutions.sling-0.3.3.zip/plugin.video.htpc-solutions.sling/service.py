import plugin

####################################################################################################

if __name__ == "__main__":
	plugin.update_boxes()
	plugin.update_channels()
	plugin.update_genres()