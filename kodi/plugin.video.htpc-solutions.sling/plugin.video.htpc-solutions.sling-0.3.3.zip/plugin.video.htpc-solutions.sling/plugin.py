from boto3.dynamodb.conditions import Key, Attr
from ConfigParser import ConfigParser
from tinydb import TinyDB, where

import boto3
import htpcsolutions.cookies as cookies
import htpcsolutions.debug as debug
import htpcsolutions.http as http
import htpcsolutions.parameters as parameters
import htpcsolutions.settings as settings
import htpcsolutions.ui as ui
import json
import operator
import os
import subprocess
import xbmc, xbmcaddon

####################################################################################################

cookies_file = xbmc.translatePath("special://userdata/addon_data/%s/cookies.lwp" % ( xbmcaddon.Addon().getAddonInfo('id') ) )
db_file = xbmc.translatePath("special://userdata/addon_data/%s/db.json" % ( xbmcaddon.Addon().getAddonInfo('id') ) )
tvguide_file = xbmc.translatePath("special://home/addons/script.tvguide/resources/addons.ini")

####################################################################################################

if not os.path.isdir(os.path.dirname(db_file)):
	os.makedirs(os.path.dirname(db_file))

####################################################################################################

addon = xbmcaddon.Addon()
db = TinyDB(db_file)
boxes = db.table("boxes")
channels = db.table("channels")
genres = db.table("genres")
config = ConfigParser()
jar = cookies.load(filename = cookies_file)

####################################################################################################

session = boto3.session.Session(
	aws_access_key_id = 'AKIAJJLHNPK7TLGXI2SQ',
	aws_secret_access_key = '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',
	region_name = 'eu-west-1'
)
dynamodb = session.resource('dynamodb')

####################################################################################################

@property
def hasCredentials():
	
	if (settings.get('credentials.username') == "" or settings.get('credentials.password') == ""):
		return False
	else:
		return True

def integrate():

	debug.notice("Integrating with TVGuide Addon")
	
	config.read(tvguide_file)

	if config.has_section(addon.getAddonInfo('id')):
		config.remove_section(addon.getAddonInfo('id'))

	config.add_section(addon.getAddonInfo('id'))

	for channel in channels.all():
		config.set(addon.getAddonInfo('id'), channel['name'], "plugin://{0}/?mode=client&action=launch&id={1}&name={2}".format( addon.getAddonInfo('id'), channel['id'], quote_plus(channel['name']) ) )

	with open(tvguide_file, 'wb') as configfile:
		config.write(configfile)

def launch(**kwargs):

	executable = kwargs.get("executable", xbmc.translatePath(addon.getAddonInfo('path') + "/resources/bin/client.exe").decode('utf-8') )

	if hasCredentials == True and self.boxes.count == 0:
		update_boxes()
	
	for box in boxes.all():
		arguments = [
			executable,
			"--credentials-username", box['username'],
			"--credentials-password", box['password'],
			"--box-finderid", box['finderId'],
			"--box-name", box['name'],
			"--debug-enabled", settings.get('debug.enabled')
		]

	if parameters.has('number'):
		arguments.extend(["--channel-number", parameters.get('number')])

	debug.notice(arguments)

	_process = subprocess.Popen(arguments, stdin=subprocess.PIPE, stdout=subprocess.PIPE)

def list_boxes(**kwargs):
	
	name = kwargs.get('name', None)
	value = kwargs.get('value', None)

	for box in boxes.all():
		ui.add(box["name"], "settings", "set", image=None, isFolder=False, params = { "name": "box.default", "value": box["id"] } ) 
	ui.end()

def list_channels():
	
	debug.notice(parameters._parameters)

	if parameters.has("genre"):
		chans = channels.search(where('genre') == int(parameters.get("genre")))
	elif parameters.has("favourite"):
		chans = channels.search(where('favourite') == 1)
	else:
		chans = channels.all()

	for c in chans:
		ui.add(c["name"], "launch", None, image=c["thumb"], isFolder=False, params = dict(c) )
	ui.end()

def list_genres():

	for genre in genres.all():
		ui.add(genre["name"], "list", "channels", image=genre["thumb"], isFolder=True, params = { 'genre': genre["id"] }) 
	ui.end()

def list_main():
	ui.add("Favourites", "list", "channels", image=None, isFolder=True, params = { 'favourite': 1 })
	ui.add("All Channels", "list", "channels", image=None, isFolder=True)
	ui.add("Genres", "list", "genres", image=None, isFolder=True)
	ui.add("Quick Connect", "launch", None, image=None, isFolder=False)
	ui.add("Settings", "settings", "open", image=None, isFolder=False)
	ui.end()

def update_boxes():

	debug.notify("Performing Update")

	if validate() == True:

		jar.set(name="slingboxLocale", value="en_uk", domain="slingbox.com", path="/", version=0)
		response = http.get(url = "https://newwatchsecure.slingbox.com/watch/slingAccounts/account_boxes_js", cookies = jar)

		if not response.data:
			debug.notify("Update Failed - No Data From Server")
			debug.error("No data was return from the server")
			return False

		# Check to see if we've received anything.
		if (response.data == ""):
			debug.notify("Update Failed - JSON is invalid")
			return False

		# replace invalid json information
		data = json.loads(response.data.replace("var sling_account_boxes=",""))

		# Remove all exisiting records
		boxes.remove()

		# Enumerate JSON Category
		for item in data['memberslingbox']:
			box = data['memberslingbox'][item]
			boxes.insert({
				'name': box['displayName'],
				'finderId': box['finderId'],
				'id': item,
				'username': 'admin',
				'password': box['adminPassword']
			})
	else:
		debug.notice("Failed to validate beofre box update")

def update_channels():
		
	debug.notice("Performing Channel Update")
	
	response = dynamodb.Table("Channels").query( KeyConditionExpression = Key('Service').eq('SkyUK') )
	meta = response['ResponseMetadata']

	if (meta['HTTPStatusCode'] == 200) and (response['Count'] > 0):
		channels.remove()
		for i in response['Items']:

			i['Favourite'] = 0

			channels.insert({
				'favourite': i['Favourite'],
				'genre': int(i['Genre']),
				'id': int(i['Id']),
				'number': int(i['Number']),
				'name': i['Name'],
				'thumb': ('http://epgstatic.sky.com/epgdata/1.0/newchanlogos/500/500/skychb%s.png' % int(i['Id']) )
			})

	debug.notice("Channel Update Complete")

def update_genres():

	debug.notice("Performing Genres Update")

	response = dynamodb.Table("Genres").query( KeyConditionExpression = Key('Type').eq('Channel') )
	meta = response['ResponseMetadata']

	if (meta['HTTPStatusCode'] == 200) and (response['Count'] > 0):
			genres.remove()
			for i in response['Items']:
				debug.notice(i)
				genres.insert({
					'id': int(i['Id']),
					'name': i['Name'],
					'thumb': ''
				})

	debug.notice("Genre Update Complete")

def validate(**kwargs):

	username = kwargs.get("username", settings.get('credentials.username'))
	password = kwargs.get("password", settings.get('credentials.password'))

	for i in range(2):
		response = http.get(url = "https://accounts.sling.com/accounts/sling/login/loginForm", cookies = jar, data = {
			'emailAddress': username,
			'password': password
		})

	if response.data == None:
		debug.error("No data was return from server")
		return False

	response.cookies.save()

	if not response.data.find('<a href="/accounts/member/logout">Log out</a>') == -1:
		return True
	else:
		return False

####################################################################################################

if __name__ == "__main__":

	if hasCredentials == False:
		ui.dialog("Credentials", "Please enter your Sling username and password before continuing.")
		settings.open()

	if parameters.count() < 1:
		list_main()
	
	elif parameters.has("mode") and parameters.has("action"):	

		mode = parameters.get("mode")
		action = parameters.get("action")
		
		if mode == "integrate":
			integrate()
		elif mode == "launch":
			launch()
		elif mode == "list" and action == "channels":
			list_channels()
		elif mode == "list" and action == "genres":
			list_genres()
		elif mode == "settings" and action == "clear":
			settings.clear()
		elif mode == "settings" and action == "open":
			settings.open()
		elif mode == "settings" and action == "set":
			settings.set(
				parameters.get("name"),
				parameters.get("value")
			)
		elif mode == "update" and action == 'boxes':
			update_boxes()
		elif mode == "update" and action == "channels":
			update_channels()
		elif mode == "update" and action == "genres":
			update_genres()
		else:
			debug.notice("Nice try, I don't support this mode/action")

	else:
		self.ui.end(False)
