from boto3.dynamodb.conditions import Key, Attr
from ConfigParser import ConfigParser
from tinydb import TinyDB
from urllib import quote_plus, unquote_plus, urlencode

import boto3
import htpcsolutions.cookies as cookies
import htpcsolutions.debug as debug
import htpcsolutions.http as http
import htpcsolutions.parameters as parameters
import htpcsolutions.settings as settings
import htpcsolutions.ui as ui
import operator
import os
import subprocess
import xbmc, xbmcaddon

####################################################################################################

cookies_file = xbmc.translatePath("special://userdata/addon_data/%s/cookies.lwp" % ( xbmcaddon.Addon().getAddonInfo('id') ) )
db_file = xbmc.translatePath("special://userdata/addon_data/%s/db.json" % ( xbmcaddon.Addon().getAddonInfo('id') ) )
tvguide_file = xbmc.translatePath("special://home/addons/script.tvguide/resources/addons.ini")

####################################################################################################

if not os.path.isdir(os.path.dirname(db_file)):
	os.makedirs(os.path.dirname(db_file))

####################################################################################################

addon = xbmcaddon.Addon()
db = TinyDB(db_file)
channels = db.table("channels")
config = ConfigParser()
jar = cookies.load(filename = cookies_file)

####################################################################################################

session = boto3.session.Session(
	aws_access_key_id = 'AKIAJJLHNPK7TLGXI2SQ',
	aws_secret_access_key = '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',
	region_name = 'eu-west-1'
)
dynamodb = session.resource('dynamodb')

####################################################################################################

@property
def hasCredentials():
	
	if (settings.get('credentials.username') == "" or settings.get('credentials.password') == ""):
		return False
	else:
		return True

def integrate():
	debug.notice("Integrating with TVGuide Addon")
	
	config.read(tvguide_file)

	if config.has_section(addon.getAddonInfo('id')):
		config.remove_section(addon.getAddonInfo('id'))

	config.add_section(addon.getAddonInfo('id'))

	for channel in channels.all():
		config.set(addon.getAddonInfo('id'), channel['name'], "plugin://{0}/?mode=client&action=launch&id={1}&name={2}".format( addon.getAddonInfo('id'), channel['id'], quote_plus(channel['name']) ) )

	with open(tvguide_file, 'wb') as configfile:
		config.write(configfile)

def launch(**kwargs):

	executable = kwargs.get("executable", xbmc.translatePath(addon.getAddonInfo('path') + "/resources/bin/client.exe").decode('utf-8') )
	log = kwargs.get("log", xbmc.translatePath(addon.getAddonInfo('path') + "/resources/bin/client.log").decode('utf-8') )
	mode = kwargs.get("mode", "live")
	
	_cookies = { "cookieBannerDismissed": "true" }

	for cookie in jar:
		_cookies[cookie.name] = cookie.value

	arguments = [
		executable,
		"--authorisation-identity", settings.get('authorisation.identity'),
		"--channel-id", str(parameters.get('id')),
		"--channel-name", parameters.get('name'),
		"--channel-number", str(parameters.get('id')),
		"--channel-sleep", settings.get('channel.sleep'),
		"--cookies", urlencode(_cookies),
		"--debug-enabled", settings.get('debug.enabled'),
		"--debug-level", settings.get('debug.level'),
		"--fullscreen-offset-x", settings.get('fullscreen.offset.x'),
		"--fullscreen-offset-y", settings.get('fullscreen.offset.y'),
		"--mode", mode
	]

	debug.notice(arguments)

	process = subprocess.Popen(arguments, stdin=subprocess.PIPE, stdout=subprocess.PIPE)

def list_channels():
	
	if parameters.has("genre"):
		chans = channels.search(where('genre') == parameters.get("genre"))
	elif parameters.has("favourite"):
		chans = channels.search(where('favourite') == 1)
	else:
		chans = channels.all()

	for c in chans:
		ui.add(c["name"], "client", "launch", image=c["thumb"], isFolder=False, params = dict(c) )
	ui.end()

def list_main():
	ui.add("Live TV", "list", "channels", image=None, isFolder=True)
	ui.add("Settings", "settings", "open", image=None, isFolder=False)
	ui.end()

def update():

	debug.notice("Performing Update")

	response = dynamodb.Table("Channels").query( KeyConditionExpression = Key('Service').eq('SkyGo') )
	meta = response['ResponseMetadata']
	
	if (meta['HTTPStatusCode'] == 200) and (response['Count'] > 0):
		channels.remove()
		for i in response['Items']:
			channels.insert({
				'genre': int(i['Genre']),
				'id': int(i['Id']),
				'number': int(i['Number']),
				'name': i['Name'],
				'thumb': ('http://epgstatic.sky.com/epgdata/1.0/newchanlogos/500/500/skychb%s.png' % int(i['Id']) )
			})
		debug.notice("Database Updated")

def validate(**kwargs):
	
	username = kwargs.get("username", settings.get('credentials.username'))
	password = kwargs.get("password", settings.get('credentials.password'))

	response = http.get(url = "https://skyid.sky.com/signin/skygo", cookies = jar, data = {
		'username': username,
		'password': password
	})

	if response.cookies.get(name = 'skySSO') is not None:
		response.cookies.save()
		return True
	else:
		return False

####################################################################################################

if __name__ == "__main__":

	if hasCredentials == False:
	 	ui.dialog("Credentials", "Please enter your SkyGo username and password before continuing.")
	 	settings.open()

	validate()

	if parameters.count() < 1:
		list_main()

	elif parameters.has("mode") and parameters.has("action"):	
		
		mode = parameters.get("mode")
		action = parameters.get("action")
		
		if mode == "client" and action == 'launch':
			launch()
		elif mode == "list" and action == "channels":
			list_channels()
		elif mode == "list" and action == "main":
			list_main()
		elif mode == "integrate":
			integrate()
		elif mode == "update":
			update()
		elif mode == "settings" and action == "clear":
			settings.clear()
		elif mode == "settings" and action == "open":
			settings.open()
		else:
			debug.notice("Nice try, I don't support this mode/action")

	else:
		ui.end(False)

####################################################################################################
