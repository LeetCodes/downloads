from ConfigParser import ConfigParser

import collections
import HTPCSolutions
import json
import operator
import subprocess
import sys
import xbmc, xbmcaddon

####################################################################################################

addon = xbmcaddon.Addon()
config = ConfigParser()
db = HTPCSolutions.DB()
http = HTPCSolutions.HTTP()
parameters = HTPCSolutions.Parameters()
settings = HTPCSolutions.Settings()
ui = HTPCSolutions.UI()
where = HTPCSolutions.where

####################################################################################################

class Main(HTPCSolutions.Debug):

	def __init__(self):

		if parameters.count() < 1:
			self.debug("action is default")
			
			win = GUI("sling-core.xml", addon.getAddonInfo('path').decode("utf-8"), "default")
			win.doModal()
			
			del win
		
		elif parameters.has("mode") and parameters.has("action"):	

			mode = parameters.get("mode")
			action = parameters.get("action")
			
			self.debug( "mode {0} - action {1}".format(mode, action) )

			if mode == "client" and action == "launch":
				Client().launch()
			elif mode == "boxes" and action == 'default':
				Boxes().default()
			elif mode == "boxes" and action == 'update':
				Boxes().update()
			elif mode == "live" and action == "channels":
				Live().channels()
			elif mode == "live" and action == "genres":
				Live().genres()
			elif mode == "live" and action == "integrate":
				Live().integrate()
			elif mode == "live" and action == "update":
				Live().update()
			elif mode == "settings" and action == "clear":
				settings.clear()
			elif mode == "settings" and action == "open":
				settings.open()
			elif mode == "settings" and action == "set":
				settings.set(parameters.get("name"), parameters.get("value"))
				self.notify("Settings Updated")
			else:
				self.debug("Nice try, I don't support this mode/action")

		else:
			
			self.ui.end(False)





	
####################################################################################################

class GUI(HTPCSolutions.Window):

		def a():
			pass

#################################################

if __name__ == "__main__":
	Main()
